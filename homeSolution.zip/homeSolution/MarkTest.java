//import com.utest.marking.Markup;
//import com.utest.marking.TestMark;
//import com.utest.marking.TestMarkJoin;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class MarkTest.
 *
 * @author  Olaf Chitil
 * @version 19/2/2019
 */
//@Markup(total = 100, isPercentage = false)
public class MarkTest
{

    class GameNewQuit extends Game 
    {

        public String quit()
        {
            return "TEST";
        }
    }

    private Game game;
    private Character david;
    private Character radu;
    private Room maze;

    /**
     * Default constructor for test class MarkTest
     */
    public MarkTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        game = new Game();
        david = new Character("David", Item.FLOUR);
        radu = new Character("Radu", null);
        maze = new Room("in the maze");
        maze.setExit(Direction.EAST, maze);
        maze.setExit(Direction.WEST, maze);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**************************************************************************
     * Adding a goal
     **************************************************************************/

    @Test
    //@TestMark(value = 5)
    public void goGoal()
    {
        game.goRoom(Direction.NORTH); // hall
        game.goRoom(Direction.UP); // stairs
        game.goRoom(Direction.NORTH); // master
        String result = game.goRoom(Direction.EAST); // ensuite
        assertEquals("Incorrect message when reaching the goal.",
            game.getCurrent().getLongDescription() + 
            "\nCongratulations! You reached the goal.\nThank you for playing.  Good bye.",
            result);
    }

    @Test
    public void goalReusesQuit()
    {
        GameNewQuit game = new GameNewQuit();

        game.goRoom(Direction.NORTH); // hall
        game.goRoom(Direction.UP); // stairs
        game.goRoom(Direction.NORTH); // master
        String result = game.goRoom(Direction.EAST); // ensuite
        assertTrue("Adding goal should reuse existing quit method.",
            result.contains("TEST"));
    }

    @Test
    //@TestMark(value = 5)
    public void goInvalidStepsGoal()
    {
        String ig1 = game.goRoom(Direction.NORTH); // hall
        String ig2 = game.goRoom(Direction.UP); // stairs
        String ig3 = game.goRoom(Direction.NORTH); // master
        game.goRoom(Direction.WEST); // invalid
        game.goRoom(Direction.NORTH); // invalid
        game.goRoom(Direction.WEST); // invalid
        game.goRoom(Direction.NORTH); // invalid
        game.goRoom(Direction.WEST); // invalid
        game.goRoom(Direction.NORTH); // invalid
        game.goRoom(Direction.WEST); // invalid
        game.goRoom(Direction.NORTH); // invalid
        game.goRoom(Direction.WEST); // invalid
        game.goRoom(Direction.NORTH); // invalid       
        String result = game.goRoom(Direction.EAST); // ensuite
        assertEquals("Should reach goal after only 4 steps.",
            game.getCurrent().getLongDescription() + 
            "\nCongratulations! You reached the goal.\nThank you for playing.  Good bye.",
            result);
    }

    @Test
    //@TestMark(value = 5)
    public void finishedAtGoal()
    {
        String ig1 = game.goRoom(Direction.NORTH);
        String ig2 = game.goRoom(Direction.UP);
        String ig3 = game.goRoom(Direction.NORTH);
        String ig4 = game.goRoom(Direction.EAST);
        assertEquals("Finished at goal.", true, game.finished());        
    }

    @Test
    //@TestMark(value = 5)
    public void notFinishedBeforeGoal()
    {
        String ig1 = game.goRoom(Direction.NORTH);
        String ig2 = game.goRoom(Direction.UP);
        String ig3 = game.goRoom(Direction.NORTH);
        assertEquals("Finished before reaching goal.", false, game.finished());        
    }

    /**************************************************************************
     * Adding time
     **************************************************************************/

    @Test
    public void runningOutOfTime()
    {
        game.goRoom(Direction.NORTH); // 1 hall
        game.goRoom(Direction.UP); // 2 stairs
        game.goRoom(Direction.NORTH); // 3 master
        game.goRoom(Direction.SOUTH); // 4 stairs
        game.goRoom(Direction.NORTH); // 5 master
        game.goRoom(Direction.SOUTH); // 6 stairs
        game.goRoom(Direction.NORTH); // 7 master
        game.goRoom(Direction.SOUTH); // 8 stairs
        game.goRoom(Direction.NORTH); // 9 master
        game.goRoom(Direction.SOUTH); // 10 stairs
        game.goRoom(Direction.NORTH); // 11 master
        String result = game.goRoom(Direction.SOUTH); // 12 stairs
        assertEquals(game.getCurrent().getLongDescription() + 
            "\nLost! You ran out of time.\nThank you for playing.  Good bye.", 
            result); 
    }

    @Test
    public void reachGoalJustInTime()
    {
        game.goRoom(Direction.NORTH); // 1 hall
        game.goRoom(Direction.UP); // 2 stairs
        game.goRoom(Direction.NORTH); // 3 master
        game.goRoom(Direction.SOUTH); // 4 stairs
        game.goRoom(Direction.NORTH); // 5 master
        game.goRoom(Direction.SOUTH); // 6 stairs
        game.goRoom(Direction.NORTH); // 7 master
        game.goRoom(Direction.SOUTH); // 8 stairs
        game.goRoom(Direction.NORTH); // 9 master
        game.goRoom(Direction.SOUTH); // 10 stairs
        game.goRoom(Direction.NORTH); // 11 master

        String result = game.goRoom(Direction.EAST); // 12 ensuite
        assertEquals("Should win reaching goal after 12 steps.",
            game.getCurrent().getLongDescription() + 
            "\nCongratulations! You reached the goal.\nThank you for playing.  Good bye.",
            result);        
    }

    @Test
    public void timerReusesQuit()
    {
        GameNewQuit game = new GameNewQuit();

        game.goRoom(Direction.NORTH); // 1 hall
        game.goRoom(Direction.UP); // 2 stairs
        game.goRoom(Direction.NORTH); // 3 master
        game.goRoom(Direction.SOUTH); // 4 stairs
        game.goRoom(Direction.NORTH); // 5 master
        game.goRoom(Direction.SOUTH); // 6 stairs
        game.goRoom(Direction.NORTH); // 7 master
        game.goRoom(Direction.SOUTH); // 8 stairs
        game.goRoom(Direction.NORTH); // 9 master
        game.goRoom(Direction.SOUTH); // 10 stairs
        game.goRoom(Direction.NORTH); // 11 master
        String result = game.goRoom(Direction.SOUTH); // 12 stairs
        assertTrue("Adding time should reuse quit method.",
            result.contains("TEST"));
    }

    /**************************************************************************
     * Adding a look command
     **************************************************************************/

    @Test
    public void lookImmidiately()
    {
        assertEquals("Looking at start should give long description of front.",
            game.getCurrent().getLongDescription(), game.look());
    }

    @Test
    public void lookAfterStep()
    {
        String ignore = game.goRoom(Direction.NORTH); 
        assertEquals("Looking after one step should yield long description of hall.",
            game.getCurrent().getLongDescription(), game.look());
    }

    @Test
    public void commandLook()
    {
        Parser p = new Parser();
        assertTrue("``look'' should be listed as command when player asks for help.",
            p.commands().contains("look"));
    }

    /**************************************************************************
     * Adding Items
     **************************************************************************/

    @Test
    public void itemFlour()
    {
        assertEquals("flour", Item.FLOUR.toString());
    }

    @Test
    public void itemSugar()
    {
        assertEquals("sugar", Item.SUGAR.toString());
    }

    @Test
    public void itemEgg()
    {
        assertEquals("egg", Item.EGG.toString());
    }

    /**************************************************************************
     * Adding Characters
     **************************************************************************/

    @Test
    public void takeFromDavid1()
    {
        assertEquals("Taking flour from David should succeed.",
            true, david.take(Item.FLOUR));
    }

    @Test
    public void takeFromDavid2()
    {
        david.take(Item.FLOUR);
        assertEquals("Taking flour twice from David should fail.",
            false, david.take(Item.FLOUR));
    }

    @Test
    public void takeFromRadu()
    {
        assertEquals("Taking egg from Radu should fail.",
            false, radu.take(Item.EGG));
    }

    @Test
    //@TestMark(value = 5)
    public void repeatedTake()
    {
        Character paul = new Character("Paul", Item.EGG);
        assertEquals("Paul having the item egg", paul.toString());
        assertEquals("Character.take should return false when trying to take wrong item.", 
            false, paul.take(Item.FLOUR));
        assertEquals("Character.take should return false when trying to take wrong item 2nd time.", 
            false, paul.take(Item.FLOUR));
        assertEquals("Character.take should return true when item successfully taken.", 
            true, paul.take(Item.EGG));
        assertEquals("Character.take should return false when item taken twice.", 
            false, paul.take(Item.EGG));
    }

    /**************************************************************************
     * Adding Characters to Rooms
     **************************************************************************/
    
     @Test
    public void longDescriptionChar()
    {
        maze.addCharacter(new Character("Tom", null));
        assertEquals("Wrong description of the room with Tom.",
            "You are in the maze.\nExits: west east\nCharacters: Tom; ",
            maze.getLongDescription());
    }

    /**
     * Check long description with two characters.
     */
    @Test
    public void longDescriptionChar2()
    {
        maze.addCharacter(new Character("Jason", null));
        maze.addCharacter(new Character("David", Item.EGG));
        assertEquals("Wrong description of the room with Jason and David.",
            "You are in the maze.\nExits: west east\nCharacters: Jason; David having the item egg; ",
            maze.getLongDescription());
    }

    @Test
    public void descDavid()
    {
        assertEquals("david.toString() yields wrong description.",
            "David having the item flour", david.toString());
    }

    @Test
    public void descRadu()
    {
        assertEquals("radu.toString() yields wrong description.",
            "Radu", radu.toString());
    }

    @Test
    public void takeItem()
    {
        maze.addCharacter(new Character("David", Item.EGG));
        assertEquals("You should succeed in taking egg from David.",
            true, maze.take(Item.EGG));
    }
    
    @Test
    public void takeItemAtATime()
    {
        maze.addCharacter(new Character("Dick", Item.EGG));
        maze.addCharacter(new Character("Don", Item.EGG));
        
        maze.take(Item.EGG);
        assertTrue("Should be able to take two eggs.",
            maze.take(Item.EGG));
        assertEquals("Should not be able to take three eggs.",
            false, maze.take(Item.EGG));
    }

    @Test
    public void visitAllCharacters()
    {   // go through whole house and collect all long descriptions in String s
        String s = game.goRoom(Direction.NORTH); // hall
        s += game.goRoom(Direction.WEST); // cloakroom
        game.goRoom(Direction.EAST); // hall
        s += game.goRoom(Direction.NORTH); // living room
        s += game.goRoom(Direction.NORTH); // garden
        game.goRoom(Direction.SOUTH); // living room
        s += game.goRoom(Direction.EAST); // kitchen
        game.goRoom(Direction.WEST); // hall
        s += game.goRoom(Direction.UP); // stairs
        s += game.goRoom(Direction.SOUTH); // guest
        // new game, because otherwise run out of time
        game = new Game();
        game.goRoom(Direction.NORTH); // hall
        game.goRoom(Direction.UP); // stairs
        s += game.goRoom(Direction.NORTH); // masters
        s += game.goRoom(Direction.EAST); // ensuite
        assertTrue("Visiting the whole house we should meet the mother.",
            s.contains("mother"));
        assertTrue("Visiting the whole house we should meet the daughter.",
            s.contains("daughter"));
        assertTrue("Visiting the whole house we should meet the father.",
            s.contains("father"));
        assertTrue("Visiting the whole house we should meet the son.",
            s.contains("son"));
        assertTrue("Visiting the whole house we should see the flour.",
            s.contains("flour"));
        assertTrue("Visiting the whole house we should see the egg.",
            s.contains("egg"));
        assertTrue("Visiting the whole house we should see the sugar.",
            s.contains("sugar"));        
    }

    @Test
    public void takeAllItems()
    {
        boolean egg = false;
        boolean sugar = false;
        boolean flour = false;

        // go through whole house an collect all items
        game.goRoom(Direction.NORTH); // hall
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.WEST); // cloakroom
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.EAST); // hall
        game.goRoom(Direction.NORTH); // living room
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.NORTH); // garden
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.SOUTH); // living room
        game.goRoom(Direction.EAST); // kitchen
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.WEST); // hall
        game.goRoom(Direction.UP); // stairs
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.SOUTH); // guest
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        // new game, because otherwise run out of time
        game = new Game();
        game.goRoom(Direction.NORTH); // hall
        game.goRoom(Direction.UP); // stairs
        game.goRoom(Direction.NORTH); // masters
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        game.goRoom(Direction.EAST); // ensuite
        egg = egg || game.getCurrent().take(Item.EGG);
        sugar = sugar || game.getCurrent().take(Item.SUGAR);
        flour = flour || game.getCurrent().take(Item.FLOUR);
        assertTrue("Taking everything in every room should get egg.", egg);
        assertTrue("Taking everything in every room should get sugar.", sugar);
        assertTrue("Taking everything in every room should get flour.", flour);

    }

    /**************************************************************************
     * Adding a take command
     **************************************************************************/

    @Test
    public void takeFail()
    {
        assertEquals("You should not be able to take an item that is not there",
            "Item not in this room.", game.take(Item.EGG));
    }

    @Test
    public void takeSucceed()
    {
        game.getCurrent().addCharacter(new Character("Palani", Item.FLOUR));
        assertEquals("You should succeed taking an item that is there.",
            "Item taken.", game.take(Item.FLOUR));
    }
    
    @Test
    public void takeTwiceFails()
    {
        game.getCurrent().addCharacter(new Character("Palani", Item.FLOUR));
        game.take(Item.FLOUR);
        assertEquals("You should not be able to take the same item twice.",
            "Item not in this room.", game.take(Item.FLOUR));
    }

    @Test
    public void commandTake()
    {
        Parser p = new Parser();
        assertTrue("``take'' should be listed as command when player asks for help.",
            p.commands().contains("look"));
    }

    /**************************************************************************
     * Adding a cook command
     **************************************************************************/

    @Test
    //@TestMark(value = 1)
    public void cookFail()
    {
        assertEquals("You should not be able to cook at start of game.",
            "You cannot cook yet.", game.cook());
    }

    @Test
    public void cookSucceed()
    {
        Room here = game.getCurrent();
        here.addCharacter(new Character("Laura", Item.FLOUR));
        here.addCharacter(new Character("Andy", Item.EGG));
        here.addCharacter(new Character("Rogerio", Item.SUGAR));
        assertEquals("Item taken.", game.take(Item.FLOUR));
        assertEquals("Item taken.", game.take(Item.EGG));
        assertEquals("Item taken.", game.take(Item.SUGAR));
        game.goRoom(Direction.NORTH);
        game.goRoom(Direction.EAST); // kitchen
        assertEquals("You should be able to cook in kitchen after taking all items.",
            "Congratulations! You have won.\nThank you for playing.  Good bye.", 
            game.cook());
    }

    @Test
    public void cookWrongRoom()
    {
        Room here = game.getCurrent();
        here.addCharacter(new Character("Laura", Item.FLOUR));
        here.addCharacter(new Character("Andy", Item.EGG));
        here.addCharacter(new Character("Rogerio", Item.SUGAR));
        assertEquals("Item taken.", game.take(Item.FLOUR));
        assertEquals("Item taken.", game.take(Item.EGG));
        assertEquals("Item taken.", game.take(Item.SUGAR));
        game.goRoom(Direction.NORTH); // hall
        assertEquals("You should not be able to cook outside the kitchen.",
            "You cannot cook yet.", game.cook());
    }

    @Test
    public void cookMissingItems()
    {
        Room here = game.getCurrent();
        here.addCharacter(new Character("Laura", Item.FLOUR));
        here.addCharacter(new Character("Andy", Item.EGG));
        here.addCharacter(new Character("Rogerio", Item.EGG));
        assertEquals("Item taken.", game.take(Item.FLOUR));
        assertEquals("Item taken.", game.take(Item.EGG));
        assertEquals("Item taken.", game.take(Item.EGG));
        game.goRoom(Direction.NORTH);
        game.goRoom(Direction.EAST); // kitchen
        assertEquals("You should not be able to cook without sugar.",
            "You cannot cook yet.", game.cook());
    }

    @Test
    public void commandCook()
    {
        Parser p = new Parser();
        assertTrue("``cook'' should be listed as command when player asks for help.",
            p.commands().contains("look"));
    }

}
