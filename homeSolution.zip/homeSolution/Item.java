
/**
 * Enumeration class Item
 * The items in the game.
 *
 * @author Olaf Chitil
 * @version 4/2/2019
 */
public enum Item
{
    FLOUR,

    SUGAR,

    EGG;

    /**
     * Return the description of the item.
     */
    public String toString()
    {
        return ""; // TO DO
    }
}
